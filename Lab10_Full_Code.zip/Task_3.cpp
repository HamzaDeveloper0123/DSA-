
#include <iostream>
using namespace std;

int maxElement(int arr[],int size)
{
    if(size==1) return arr[0];
    int mx=maxElement(arr+1,size-1);
    return (arr[0]>mx)?arr[0]:mx;
}

int main()
{
    int arr[]={12,5,18,7,3};
    cout<<"Maximum element: "<<maxElement(arr,5);
}
