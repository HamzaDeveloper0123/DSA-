
#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* next;
    Node* prev;
    Node(int d){data=d; next=NULL; prev=NULL;}
};

Node* insertEnd(Node* head,int value){
    if(head==NULL) return new Node(value);

    if(head->next==NULL){
        Node* temp=new Node(value);
        head->next=temp;
        temp->prev=head;
        return head;
    }

    insertEnd(head->next,value);
    return head;
}

void printForward(Node* head){
    if(head==NULL) return;
    cout<<head->data<<" ";
    printForward(head->next);
}

int main(){
    Node* head=NULL;
    head=insertEnd(head,1);
    head=insertEnd(head,2);
    head=insertEnd(head,3);
    printForward(head);
}
