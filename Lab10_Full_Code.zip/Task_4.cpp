
#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* next;
    Node(int d){data=d; next=NULL;}
};

void printList(Node* head)
{
    if(head==NULL) return;
    cout<<head->data<<" ";
    printList(head->next);
}

int main()
{
    Node* head=new Node(10);
    head->next=new Node(20);
    head->next->next=new Node(30);
    printList(head);
}
