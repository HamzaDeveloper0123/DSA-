
#include <iostream>
#include <string>
using namespace std;

bool palindrome(string str,int start,int end)
{
    if(start >= end) return true;
    if(str[start] != str[end]) return false;
    return palindrome(str,start+1,end-1);
}

int main()
{
    string str = "madam";
    cout << (palindrome(str,0,str.length()-1) ? "Palindrome" : "Not Palindrome");
    return 0;
}
