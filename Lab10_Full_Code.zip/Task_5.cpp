
#include <iostream>
using namespace std;

struct Node{
    int data;
    Node* next;
    Node(int d){data=d; next=NULL;}
};

void print(Node* head){
    if(head==NULL){ cout<<endl; return; }
    cout<<head->data<<" ";
    print(head->next);
}

Node* insertEnd(Node* head,int value){
    if(head==NULL) return new Node(value);
    head->next=insertEnd(head->next,value);
    return head;
}

int main(){
    Node* head=NULL;
    head=insertEnd(head,10);
    head=insertEnd(head,20);
    head=insertEnd(head,30);
    print(head);
}
