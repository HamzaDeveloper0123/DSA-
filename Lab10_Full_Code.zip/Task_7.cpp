
#include <iostream>
using namespace std;

bool subsetSum(int arr[],int n,int target){
    if(target==0) return true;
    if(n==0) return false;

    return subsetSum(arr,n-1,target) ||
           subsetSum(arr,n-1,target-arr[n-1]);
}

int main(){
    int arr[]={2,3,5,8};
    if(subsetSum(arr,4,13))
        cout<<"Magic Number = 13";
    else
        cout<<"-1";
}
