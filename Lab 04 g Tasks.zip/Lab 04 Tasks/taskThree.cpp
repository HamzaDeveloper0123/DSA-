#include <iostream>
#include <queue>
#include <stack>
using namespace std;

void reverseFirstK(queue<int> &q, int k)
{
  if (k <= 1 || k > q.size())
    return;
  stack<int> st;
  for (int i = 0; i < k; i++)
  {
    st.push(q.front());
    q.pop();
  }
  while (!st.empty())
  {
    q.push(st.top());
    st.pop();
  }
  int remaining = q.size() - k;
  for (int i = 0; i < remaining; i++)
  {
    q.push(q.front());
    q.pop();
  }
}

int main()
{
  queue<int> q;
  int n, x, k;
  cout << "Enter number of elements: ";
  cin >> n;

  cout << "Enter elements: ";
  for (int i = 0; i < n; i++)
  {
    cin >> x;
    q.push(x);
  }
  cout << "Enter value of K: ";
  cin >> k;

  reverseFirstK(q, k);

  cout << "Output: ";
  while (!q.empty())
  {
    cout << q.front() << " ";
    q.pop();
  }

  return 0;
}