#include <iostream>
#include <queue>
using namespace std;

class TicketSystem
{
private:
  queue<int> tickets;

public:
  void enqueue(int ticket_id)
  {
    tickets.push(ticket_id);
    cout << "Ticket " << ticket_id << " added.\n";
  }

  void dequeue()
  {
    if (tickets.empty())
    {
      cout << "No tickets to resolve.\n";
      return;
    }
    cout << "Resolved Ticket: " << tickets.front() << endl;
    tickets.pop();
  }

  void front()
  {
    if (tickets.empty())
    {
      cout << "No tickets in queue.\n";
      return;
    }
    cout << "Next Ticket: " << tickets.front() << endl;
  }

  void display()
  {
    if (tickets.empty())
    {
      cout << "No pending tickets.\n";
      return;
    }
    queue<int> temp = tickets;

    cout << "Pending Tickets: ";
    while (!temp.empty())
    {
      cout << temp.front() << " ";
      temp.pop();
    }
    cout << endl;
  }
};

int main()
{
  TicketSystem system;
  int choice, ticket_id;
  do
  {
    cout << "\n--- Customer Support Ticket System ---\n";
    cout << "1. Add Ticket\n";
    cout << "2. Resolve Ticket\n";
    cout << "3. View Next Ticket\n";
    cout << "4. Display All Tickets\n";
    cout << "5. Exit\n";
    cout << "Enter choice: ";
    cin >> choice;

    switch (choice)
    {
    case 1:
      cout << "Enter 4-digit Ticket ID: ";
      cin >> ticket_id;
      system.enqueue(ticket_id);
      break;
    case 2:
      system.dequeue();
      break;
    case 3:
      system.front();
      break;
    case 4:
      system.display();
      break;
    case 5:
      cout << "Exiting...\n";
      break;
    default:
      cout << "Invalid choice!\n";
    }
  } while (choice != 5);
  return 0;
}