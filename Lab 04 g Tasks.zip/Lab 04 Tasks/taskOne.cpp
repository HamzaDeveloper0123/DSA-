#include <iostream>
using namespace std;

template <typename T>
class AbstractQueue
{
public:
  virtual void enQueue(T value) = 0;
  virtual T deQueue() = 0;
  virtual T front() const = 0;
  virtual bool isEmpty() const = 0;
  virtual bool isFull() const = 0;
  virtual ~AbstractQueue() {}
};

template <typename T>
class myQueue : public AbstractQueue<T>
{
private:
  T *arr;
  int frontIndex, rearIndex, size, capacity;

public:
  myQueue(int cap)
  {
    capacity = cap;
    arr = new T[capacity];
    frontIndex = 0;
    rearIndex = -1;
    size = 0;
  }
  void enQueue(T value)
  {
    if (isFull())
    {
      cout << "Queue is Full\n";
      return;
    }
    rearIndex = (rearIndex + 1) % capacity;
    arr[rearIndex] = value;
    size++;
  }
  T deQueue()
  {
    if (isEmpty())
    {
      cout << "Queue is Empty\n";
      return -1;
    }
    T val = arr[frontIndex];
    frontIndex = (frontIndex + 1) % capacity;
    size--;
    return val;
  }
  T front() const
  {
    if (isEmpty())
    {
      cout << "Queue is Empty\n";
      return -1;
    }
    return arr[frontIndex];
  }
  bool isEmpty() const
  {
    return size == 0;
  }

  bool isFull() const
  {
    return size == capacity;
  }
  void display() const
  {
    if (isEmpty())
    {
      cout << "Queue is Empty\n";
      return;
    }
    int i = frontIndex;
    for (int count = 0; count < size; count++)
    {
      cout << arr[i] << " ";
      i = (i + 1) % capacity;
    }
    cout << endl;
  }
};

int main()
{
  myQueue<int> q(5);
  int choice, value;
  do
  {
    cout << "\n1. Enqueue\n2. Dequeue\n3. Front\n4. Display\n5. Exit\n";
    cout << "Enter choice: ";
    cin >> choice;
    switch (choice)
    {
    case 1:
      cout << "Enter value: ";
      cin >> value;
      q.enQueue(value);
      break;
    case 2:
      cout << "Removed: " << q.deQueue() << endl;
      break;
    case 3:
      cout << "Front: " << q.front() << endl;
      break;
    case 4:
      q.display();
      break;
    }
  } while (choice != 5);
  return 0;
}