#include <iostream>
#include <stack>
using namespace std;

class QueueUsingStacks
{
private:
  stack<int> s1, s2;

public:
  void enqueue(int x)
  {
    s1.push(x);
  }
  int dequeue()
  {
    if (s1.empty() && s2.empty())
    {
      cout << "Queue is Empty\n";
      return -1;
    }
    if (s2.empty())
    {
      while (!s1.empty())
      {
        s2.push(s1.top());
        s1.pop();
      }
    }
    int val = s2.top();
    s2.pop();
    return val;
  }
  int front()
  {
    if (s1.empty() && s2.empty())
    {
      cout << "Queue is Empty\n";
      return -1;
    }
    if (s2.empty())
    {
      while (!s1.empty())
      {
        s2.push(s1.top());
        s1.pop();
      }
    }
    return s2.top();
  }
  void display()
  {
    if (s1.empty() && s2.empty())
    {
      cout << "Queue is Empty\n";
      return;
    }
    stack<int> temp = s2;
    while (!temp.empty())
    {
      cout << temp.top() << " ";
      temp.pop();
    }
    temp = s1;
    int arr[100], i = 0;

    while (!temp.empty())
    {
      arr[i++] = temp.top();
      temp.pop();
    }
    for (int j = i - 1; j >= 0; j--)
    {
      cout << arr[j] << " ";
    }
    cout << endl;
  }
};

int main()
{
  QueueUsingStacks q;
  q.enqueue(10);
  q.enqueue(20);
  q.enqueue(30);
  q.display();

  cout << "Removed: " << q.dequeue() << endl;
  cout << "Front: " << q.front() << endl;

  q.display();

  return 0;
}