#include <iostream>
#include <queue>
#include <string>
using namespace std;

class Package
{
public:
  int id;
  string address;
  int startTime;
  int endTime;

  Package(int i, string a, int s, int e)
  {
    id = i;
    address = a;
    startTime = s;
    endTime = e;
  }
};

class DeliveryQueue
{
private:
  queue<Package> q;
public:
  void enqueue(int id, string address, int startTime, int endTime)
  {
    Package p(id, address, startTime, endTime);
    q.push(p);
    cout << "Package added successfully.\n";
  }
  void dequeue(int currentTime)
  {
    if (q.empty())
    {
      cout << "No packages in queue.\n";
      return;
    }
    while (!q.empty() && currentTime > q.front().endTime)
    {
      cout << "Package ID " << q.front().id << " expired and skipped.\n";
      q.pop();
    }
    if (q.empty())
    {
      cout << "No package available for delivery.\n";
      return;
    }
    cout << "Delivering Package:\n";
    cout << "ID: " << q.front().id << endl;
    cout << "Address: " << q.front().address << endl;
    cout << "Time Window: " << q.front().startTime << " to " << q.front().endTime << endl;
    q.pop();
  }
  void front(int currentTime)
  {
    if (q.empty())
    {
      cout << "No packages in queue.\n";
      return;
    }
    while (!q.empty() && currentTime > q.front().endTime)
    {
      cout << "Package ID " << q.front().id << " expired and skipped.\n";
      q.pop();
    }
    if (q.empty())
    {
      cout << "No package available in queue.\n";
      return;
    }
    cout << "Front Package:\n";
    cout << "ID: " << q.front().id << endl;
    cout << "Address: " << q.front().address << endl;
    cout << "Time Window: " << q.front().startTime << " to " << q.front().endTime << endl;
  }
  void display()
  {
    if (q.empty())
    {
      cout << "No packages in queue.\n";
      return;
    }
    queue<Package> temp = q;
    cout << "\nPackages in Queue:\n";
    while (!temp.empty())
    {
      cout << "ID: " << temp.front().id
           << ", Address: " << temp.front().address
           << ", Time Window: " << temp.front().startTime
           << " to " << temp.front().endTime << endl;
      temp.pop();
    }
  }
  void timeToDeliver(int currentTime)
  {
    if (q.empty())
    {
      cout << "No packages in queue.\n";
      return;
    }
    if (currentTime > q.front().endTime)
    {
      cout << "Front package expired.\n";
    }
    else
    {
      cout << "Front package can still be delivered within time window.\n";
    }
  }
};

int main()
{
  DeliveryQueue dq;
  int choice;
  int id, startTime, endTime, currentTime;
  string address;
  do
  {
    cout << "\n===== Real-Time Package Delivery System =====\n";
    cout << "1. Add Package\n";
    cout << "2. Deliver Package\n";
    cout << "3. View Front Package\n";
    cout << "4. Display All Packages\n";
    cout << "5. Check Time To Deliver Front Package\n";
    cout << "6. Exit\n";
    cout << "Enter choice: ";
    cin >> choice;

    switch (choice)
    {
    case 1:
      cout << "Enter Package ID: ";
      cin >> id;
      cout << "Enter Delivery Address: ";
      cin.ignore();
      getline(cin, address);
      cout << "Enter Start Time: ";
      cin >> startTime;
      cout << "Enter End Time: ";
      cin >> endTime;
      dq.enqueue(id, address, startTime, endTime);
      break;
    case 2:
      cout << "Enter Current Time: ";
      cin >> currentTime;
      dq.dequeue(currentTime);
      break;
    case 3:
      cout << "Enter Current Time: ";
      cin >> currentTime;
      dq.front(currentTime);
      break;
    case 4:
      dq.display();
      break;
    case 5:
      cout << "Enter Current Time: ";
      cin >> currentTime;
      dq.timeToDeliver(currentTime);
      break;
    case 6:
      cout << "Exiting program...\n";
      break;
    default:
      cout << "Invalid choice.\n";
    }
  } while (choice != 6);
  return 0;
}