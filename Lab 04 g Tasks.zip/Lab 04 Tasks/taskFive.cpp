#include <iostream>
#include <queue>
#include <string>
using namespace std;

class PrintQueue
{
private:
  queue<string> q;
public:
  void enqueue(string document_name)
  {
    q.push(document_name);
    cout << "Document added: " << document_name << endl;
  }
  void dequeue()
  {
    if (q.empty())
    {
      cout << "Queue is empty. No document to print." << endl;
      return;
    }
    cout << "Printing document: " << q.front() << endl;
    q.pop();
  }
  void front()
  {
    if (q.empty())
    {
      cout << "Queue is empty." << endl;
      return;
    }
    cout << "Front document: " << q.front() << endl;
  }
  void display()
  {
    if (q.empty())
    {
      cout << "No documents in queue." << endl;
      return;
    }
    queue<string> temp = q;
    cout << "Documents in queue: ";
    while (!temp.empty())
    {
      cout << temp.front() << " ";
      temp.pop();
    }
    cout << endl;
  }
};

int main()
{
  PrintQueue pq;
  int choice;
  string doc;
  do
  {
    cout << "\n1. Add Document\n2. Print Document\n3. View Front\n4. Display All\n5. Exit\n";
    cout << "Enter choice: ";
    cin >> choice;

    switch (choice)
    {
    case 1:
      cout << "Enter document name: ";
      cin >> doc;
      pq.enqueue(doc);
      break;
    case 2:
      pq.dequeue();
      break;
    case 3:
      pq.front();
      break;
    case 4:
      pq.display();
      break;
    case 5:
      cout << "Exiting..." << endl;
      break;
    default:
      cout << "Invalid choice!" << endl;
    }
  } while (choice != 5);
  return 0;
}