#include <iostream>
#include <string>
using namespace std;

struct Action
{
    string type;  
    char character;
};
class ActionStack
{
private:
    Action arr[100];
    int topIndex;
public:
    ActionStack()
    {
        topIndex = -1;
    }
    bool isEmpty() const
    {
        return topIndex == -1;
    }
    bool isFull() const
    {
        return topIndex == 99;
    }
    void push(Action a)
    {
        if (isFull())
        {
            cout << "Stack full.\n";
            return;
        }
        arr[++topIndex] = a;
    }
    Action pop()
    {
        if (isEmpty())
        {
            return {"", '\0'};
        }
        return arr[topIndex--];
    }
    void clear()
    {
        topIndex = -1;
    }
};
class TextEditor
{
private:
    string text;
    ActionStack undoStack;
    ActionStack redoStack;
public:
    TextEditor()
    {
        text = "";
    }
    void typeCharacter(char ch)
    {
        text += ch;
        undoStack.push({"insert", ch});
        redoStack.clear();
    }
    void deleteCharacter()
    {
        if (text.empty())
        {
            cout << "Nothing to delete.\n";
            return;
        }
        char deleted = text.back();
        text.pop_back();
        undoStack.push({"delete", deleted});
        redoStack.clear();
    }
    void undo()
    {
        if (undoStack.isEmpty())
        {
            cout << "Nothing to undo.\n";
            return;
        }
        Action last = undoStack.pop();

        if (last.type == "insert")
        {
            if (!text.empty())
                text.pop_back();
        }
        else if (last.type == "delete")
        {
            text += last.character;
        }
        redoStack.push(last);
    }
    void redo()
    {
        if (redoStack.isEmpty())
        {
            cout << "Nothing to redo.\n";
            return;
        }
        Action last = redoStack.pop();
        if (last.type == "insert")
        {
            text += last.character;
        }
        else if (last.type == "delete")
        {
            if (!text.empty())
                text.pop_back();
        }
        undoStack.push(last);
    }
    void showText() const
    {
        cout << "Current Text: " << text << endl;
    }
};
