#include <iostream>
#include "myStack.h"
using namespace std;

int main()
{
  int size;
  cout << "Enter stack size:";
  cin >> size;

  myStack<int> s(size);
  int choice, value;

  do
  {
    cout << "=====  BASIC STACK MENU =====";
    cout << "1. Push element\n";
    cout << "2. Pop element\n";
    cout << "3. Show top element\n";
    cout << "4. Check if stack is empty\n";
    cout << "5. Check if stack is full\n";
    cout << "6. Display stack elements\n";
    cout << "7. Exit\n";
    cout << "Enter choice: ";
    cin >> choice;

    switch (choice)
    {
    case 1:
      cout << "Enter value: ";
      cin >> value;
      s.push(value);
      break;
    case 2:
      if (!s.isEmpty())
        cout << "Popped element: " << s.pop() << endl;
      else
        cout << "Stack is empty.\n";
      break;
    case 3:
      if (!s.isEmpty())
        cout << "Top element:" << s.top() << endl;
      else
        cout << "Stack isempty.\n";
      break;
    case 4:
      cout << (s.isEmpty() ? "Stack is empty.\n":"Stack is not empty.\n");
      break;
    case 5:
      cout << (s.isFull() ? "Stack is full.\n":"Stack is not full.\n");
      break;
    case 6:
      s.display();
      break;
    case 7:
      cout << "Exiting..\n";
      break;
    default:
      cout << "Invalid choice.\n";
    }
  } while (choice != 7);
  
  return 0;
}