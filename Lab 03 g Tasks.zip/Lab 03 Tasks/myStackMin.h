#include <iostream>
#include "AbstractStack.h"
using namespace std;

template <typename T>
class myStackMin : public AbstractStack<T>
{
private:
  T *arr;
  T *minArr;
  int maxSize;
  int topIndex;
  int minTop;
public:
  myStackMin(int size = 10)
  {
    maxSize = size;
    arr = new T[maxSize];
    minArr = new T[maxSize];
    topIndex = -1;
    minTop = -1;
  }
  ~myStackMin()
  {
    delete[] arr;
    delete[] minArr;
  }
  void push(T value)
  {
    if (isFull())
    {
      cout << "Stack Overflow! Cannot push value.\n";
      return;
    }

    arr[++topIndex] = value;

    if (minTop == -1 || value <= minArr[minTop])
    {
      minArr[++minTop] = value;
    }
  }
  T pop()
  {
    if (isEmpty())
    {
      cout << "Stack Underflow! Stack is empty.\n";
      return T();
    }
    T removed = arr[topIndex--];
    if (removed == minArr[minTop])
    {
      minTop--;
    }
    return removed;
  }
  T top() const
  {
    if (isEmpty())
    {
      cout << "Stack is empty.\n";
      return T();
    }
    return arr[topIndex];
  }
  bool isEmpty() const
  {
    return topIndex == -1;
  }
  bool isFull() const
  {
    return topIndex == maxSize - 1;
  }
  T getMin() const
  {
    if (isEmpty())
    {
      cout << "Stack is empty.\n";
      return T();
    }
    return minArr[minTop];
  }
  void display() const
  {
    if (isEmpty())
    {
      cout << "Stack is empty.\n";
      return;
    }
    cout << "Stack elements from top to bottom:\n";
    for (int i = topIndex; i >= 0; i--)
    {
      cout << arr[i] << endl;
    }
  }
};
