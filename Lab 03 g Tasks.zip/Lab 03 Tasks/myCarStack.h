#include <iostream>
#include <string>
using namespace std;

class myCarStack
{
private:
  string arr[8];
  int topIndex;
public:
  myCarStack()
  {
    topIndex = -1;
  }
  bool isEmpty() const
  {
    return topIndex == -1;
  }
  bool isFull() const
  {
    return topIndex == 7;
  }
  void push(string carNumber)
  {
    if (isFull())
    {
      cout << "Parking lot is full.\n";
      return;
    }
    arr[++topIndex] = carNumber;
    cout << "Car parked:" << carNumber << endl;
  }
  string pop()
  {
    if (isEmpty())
    {
      return "";
    }
    return arr[topIndex--];
  }
  string top() const
  {
    if (isEmpty())
      return "";
    return arr[topIndex];
  }
  int countCars() const
  {
    return topIndex + 1;
  }
  bool searchCar(string carNumber) const
  {
    for (int i = 0; i <= topIndex; i++)
    {
      if (arr[i] == carNumber)
        return true;
    }
    return false;
  }
  void display() const
  {
    if (isEmpty())
    {
      cout << "Parking lot is empty.\n";
      return;
    }
    cout << "Cars currently parked:\n";
    for (int i = topIndex; i >= 0; i--)
    {
      cout << arr[i] << endl;
    }
  }
  void removeCar(string carNumber)
  {
    if (isEmpty())
    {
      cout << "Parking lot is empty.\n";
      return;
    }
    if (!searchCar(carNumber))
    {
      cout << "Car not found in parking.\n";
      return;
    }
    myCarStack temp;
    while (!isEmpty() && top() != carNumber)
    {
      temp.push(pop());
    }
    if (!isEmpty() && top() == carNumber)
    {
      cout << "Car removed: " << pop() << endl;
    }
    while (!temp.isEmpty())
    {
      push(temp.pop());
    }
  }
};
