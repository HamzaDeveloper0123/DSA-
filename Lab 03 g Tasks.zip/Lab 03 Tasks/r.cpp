#include <iostream>
#include "AbstractStack.h"
using namespace std;

template <typename T>
class myStack : public AbstractStack<T>
{

private:
  T *arr;
  int maxSize;
  int topIndex;

public:
  myStack(int size = 10)
  {
    maxSize = size;
    arr = new T[maxSize];
    topIndex = -1;
  }

  ~myStack()
  {
    delete[] arr;
  }

  void push(T value)
  {
    if(is)
  }
};
