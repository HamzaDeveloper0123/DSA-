#include <iostream>
#include "AbstractStack.h"
using namespace std;

template <typename T>
class myStack : public AbstractStack<T>
{
private:
  T *arr;
  int maxSize;
  int topIndex;
public:
  myStack(int size = 10)
  {
    maxSize = size;
    arr = new T[maxSize];
    topIndex = -1;
  }
  ~myStack()
  {
    delete[] arr;
  }
  void push(T value)
  {
    if (isFull())
    {
      cout << "Stack Overflow! Cannot push value.\n";
      return;
    }
    arr[++topIndex] = value;
  }
  T pop()
  {
    if (isEmpty())
    {
      cout << "Stack Underflow! Stack is empty.\n";
      return T();
    }
    return arr[topIndex--];
  }
  T top() const
  {
    if (isEmpty())
    {
      cout << "Stack is empty.\n";
      return T();
    }
    return arr[topIndex];
  }
  bool isEmpty() const
  {
    return topIndex == -1;
  }
  bool isFull() const
  {
    return topIndex == maxSize - 1;
  }
  void display() const
  {
    if (isEmpty())
    {
      cout << "Stack is empty.\n";
      return;
    }
    cout << "Stack elements from top to bottom:\n";
    for (int i = topIndex; i >= 0; i--)
    {
      cout << arr[i] << endl;
    }
  }
};
