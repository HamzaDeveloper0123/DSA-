#include <iostream>
#include "TextEditor.h"
using namespace std;

int main()
{
  TextEditor editor;
  int choice;
  char ch;
  do
  {
    cout << "===== TASK 4: TEXT EDITOR MENU =====";
    cout << "1. Type character\n";
    cout << "2. Delete character\n";
    cout << "3. Undo\n";
    cout << "4. Redo\n";
    cout << "5. Show current text\n";
    cout << "6. Exit\n";
    cout << "Enter choice: ";
    cin >> choice;
    switch (choice)
    {
    case 1:
      cout << "Enter character: ";
      cin >> ch;
      editor.typeCharacter(ch);
      break;
    case 2:
      editor.deleteCharacter();
      break;
    case 3:
      editor.undo();
      break;
    case 4:
      editor.redo();
      break;
    case 5:
      editor.showText();
      break;
    case 6:
      cout << "Exiting...\n";
      break;
    default:
      cout << "Invalid choice.\n";
    }
  } while (choice != 6);
  return 0;
}