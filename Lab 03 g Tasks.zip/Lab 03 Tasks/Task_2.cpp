#include <iostream>
#include "myStackMin.h"
using namespace std;

int main()
{
  int size;
  cout << "Enter stack size:";
  cin >> size;

  myStackMin<int> s(size);
  int choice, value;

  do
  {
    cout << "===== TASK 2: MIN STACK MENU =====";
    cout << "1. Push element\n";
    cout << "2. Pop element\n";
    cout << "3. Show top element\n";
    cout << "4. Check if stack is empty\n";
    cout << "5. Check if stack is full\n";
    cout << "6. Display stack elements\n";
    cout << "7. Show minimum element\n";
    cout << "8. Exit\n";
    cout << "Enter choice: ";
    cin >> choice;

    switch (choice)
    {
    case 1:
      cout << "Enter value: ";
      cin >> value;
      s.push(value);
      break;
    case 2:
      if (!s.isEmpty())
        cout << "Popped element: " << s.pop() << endl;
      else
        cout << "Stack is empty.\n";
      break;
    case 3:
      if (!s.isEmpty())
        cout << "Top element: " << s.top() << endl;
      else
        cout << "Stack is empty.\n";
      break;
    case 4:
      cout << (s.isEmpty() ? "Stack is empty.\n":"Stack is not empty.\n");
      break;
    case 5:
      cout << (s.isFull() ? "Stack is full.\n":"Stack is not full.\n");
      break;
    case 6:
      s.display();
      break;
    case 7:
      if (!s.isEmpty())
        cout << "Minimum element:" << s.getMin() << endl;
      else
        cout << "Stack isempty.\n";
      break;
    case 8:
      cout << "Exiting...\n";
      break;
    default:
      cout << "Invalid choice.\n";
    }
  } while (choice != 8);

  return 0;
}