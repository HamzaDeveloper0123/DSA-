#include <iostream>
#include <string>
#include "myCarStack.h"
using namespace std;

int main()
{
  myCarStack parking;
  int choice;
  string carNumber;

  do
  {
    cout << "===== TASK 3: PARKING LOT MENU =====";
    cout << "1. Park a new car\n";
    cout << "2. Remove a car by car number\n";
    cout << "3. View currently parked cars\n";
    cout << "4. View total cars parked\n";
    cout << "5. Search for a car\n";
    cout << "6. Show top car\n";
    cout << "7. Exit\n";
    cout << "Enter choice: ";
    cin >> choice;
    switch (choice)
    {
    case 1:
      cout << "Enter car number: ";
      cin >> carNumber;
      parking.push(carNumber);
      break;
    case 2:
      cout << "Enter car number to remove: ";
      cin >> carNumber;
      parking.removeCar(carNumber);
      break;
    case 3:
      parking.display();
      break;
    case 4:
      cout << "Total cars parked: " << parking.countCars() << endl;
      break;
    case 5:
      cout << "Enter car number to search: ";
      cin >> carNumber;
      if (parking.searchCar(carNumber))
        cout << "Car found in parking lot.\n";
      else
        cout << "Car not found.\n";
      break;
    case 6:
      if (!parking.isEmpty())
        cout << "Top car: " << parking.top() << endl;
      else
        cout << "Parking lot is empty.\n";
      break;
    case 7:
      cout << "Exiting...\n";
      break;
    default:
      cout << "Invalid choice.\n";
    }
  } while (choice != 7);
  return 0;
}