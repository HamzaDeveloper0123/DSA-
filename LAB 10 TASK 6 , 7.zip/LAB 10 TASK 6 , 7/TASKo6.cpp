#include <iostream>
using namespace std;

class Node
{
public:
  int data;
  Node *next;
  Node *prev;

  Node(int val)
  {
    data = val;
    next = NULL;
    prev = NULL;
  }
};

class DoublyLinkedList
{
private:
  Node *head;

public:
  DoublyLinkedList()
  {
    head = NULL;
  }

  void insertAtBeginning(int val)
  {
    Node *newNode = new Node(val);

    if (head == NULL)
    {
      head = newNode;
      return;
    }

    newNode->next = head;
    head->prev = newNode;
    head = newNode;
  }

  Node *insertAtEndRec(Node *temp, int val)
  {
    if (temp->next == NULL)
    {
      Node *newNode = new Node(val);
      temp->next = newNode;
      newNode->prev = temp;
      return temp;
    }

    insertAtEndRec(temp->next, val);
    return temp;
  }

  void insertAtEnd(int val)
  {
    if (head == NULL)
    {
      head = new Node(val);
      return;
    }
    insertAtEndRec(head, val);
  }
  void insertAtPositionRec(Node *temp, int pos, int val)
  {
    if (pos == 1)
    {
      Node *newNode = new Node(val);

      newNode->next = temp->next;
      newNode->prev = temp;

      if (temp->next != NULL)
        temp->next->prev = newNode;

      temp->next = newNode;
      return;
    }
    insertAtPositionRec(temp->next, pos - 1, val);
  }

  void insertAtPosition(int pos, int val)
  {

    if (pos == 1)
    {
      insertAtBeginning(val);
      return;
    }
    insertAtPositionRec(head, pos - 1, val);
  }

  Node *deleteByValueRec(Node *temp, int val)
  {
    if (temp == NULL)
      return NULL;
    if (temp->data == val)
    {

      if (temp->prev)
        temp->prev->next = temp->next;

      if (temp->next)
        temp->next->prev = temp->prev;
      if (temp == head)
        head = temp->next;
      delete temp;
      return NULL;
    }
    deleteByValueRec(temp->next, val);
    return temp;
  }

  void deleteByValue(int val)
  {
    deleteByValueRec(head, val);
  }

  void deleteAtPositionRec(Node *temp, int pos)
  {

    if (temp == NULL)
      return;

    if (pos == 1)
    {

      if (temp->prev)
        temp->prev->next = temp->next;

      if (temp->next)
        temp->next->prev = temp->prev;

      if (temp == head)
        head = temp->next;

      delete temp;
      return;
    }

    deleteAtPositionRec(temp->next, pos - 1);
  }

  void deleteAtPosition(int pos)
  {
    deleteAtPositionRec(head, pos);
  }

  int searchRec(Node *temp, int key, int pos)
  {

    if (temp == NULL)
      return -1;
    if (temp->data == key)
      return pos;

    return searchRec(temp->next, key, pos + 1);
  }

  int search(int key)
  {
    return searchRec(head, key, 1);
  }

  void printForwardRec(Node *temp)
  {

    if (temp == NULL)
      return;

    cout << temp->data << " ";
    printForwardRec(temp->next);
  }
  void printForward()
  {
    printForwardRec(head);
    cout << endl;
  }

  void printReverseRec(Node *temp)
  {

    if (temp == NULL)
      return;

    printReverseRec(temp->next);
    cout << temp->data << " ";
  }

  void printReverse()
  {
    printReverseRec(head);
    cout << endl;
  }

  Node *getLastNodeRec(Node *temp)
  {

    if (temp->next == NULL)
      return temp;

    return getLastNodeRec(temp->next);
  }

  bool palindromeRec(Node *left, Node *right)
  {

    if (left == right)
      return true;
    if (left->prev == right)
      return true;

    if (left->data != right->data)
      return false;

    return palindromeRec(left->next, right->prev);
  }

  bool isPalindrome()
  {

    if (head == NULL)
      return true;
    Node *tail = getLastNodeRec(head);

    return palindromeRec(head, tail);
  }
};

int main()
{

  DoublyLinkedList dll;

  dll.insertAtEnd(1);
  dll.insertAtEnd(2);
  dll.insertAtEnd(3);
  dll.insertAtEnd(2);
  dll.insertAtEnd(1);

  cout << "Forward: ";
  dll.printForward();

  cout << "Reverse: ";
  dll.printReverse();

  cout << "Search 3 at position: ";
  cout << dll.search(3) << endl;

  if (dll.isPalindrome())
    cout << "Palindrome List" << endl;
  else
    cout << "Not Palindrome" << endl;

  dll.deleteByValue(3);
  cout << "After deleting 3: ";
  dll.printForward();

  return 0;
}