
// 1. Factorial Example
int factorial(int n){
  if(n == 0 || n == 1)
  return 1;

  return n * factorial( n -1 );
}

// 2. Print Numbers 1 to N
void print(int n) {
  if(n == 0) 
  return;

  print(n - 1);

  cout << n << " ";
}



void printArray(int arr[], int n, int index = 0){
  if(index == n)
  return;

  cout << arr[index];

  printArray(arr, n, index + 1);

}



// 3. Print Numbers N to 1
void print(int n) {
  if(n == 0) 
  return;
 cout << n << " ";
  print(n - 1);
}

// 4. Sum of N Numbers

int sum(int n) {
  if( n == 0)
  return 0;

  return n + sum(n -1);
}

int sumArray(int arr[], int n){
  if(n == 0) {
    return 0;
  }


  return arr[n-1] + sumArray(arr, n-1);
}

int maximum(int arr[], int n) {
  if(n == 1)
  return arr[0];

  int smallMax = maximum(arr, n-1);
  
  if(arr[n-1] > smallMax)
  return arr[n-1];

  else 
  return maximum;

}

bool search(int arr[], int n, int target){
  if(n ==0) 
  return false;

  if(arr[n-1] == target)
  return true;

  return (arr, n-1, t);
}

int countEven(int arr[], int n)
{
  if(n == 0)
  return 0;

  if(arr[n-1] % 2 == 0)
  return 1 + countEven(arr, n-1);
  else
   return 1 + countEven(arr, n-1);
}


// 5. Power Example
int power(int p,int e){
  if(e == 0)
  return 1;

  return p * power(p, e-1);
}

// 6. Fibonacci Series
int fib(int n) {
  if(n == 0)
  return 0;

  if(n == 1)
  return 1;

  return fib( n-1 ) + (n - 2)
}


bool palindrome(string str, int st,  int ed){
  if(st>= ed)
  return true;

  if(str[st] != str[ed]){
    return false;


    return palindrome(st, st + 1, ed -1;)
  }
}


if(n == 1)
return 1;

if( [n -1 ] < arr[n - 2])
return false;

return short