#include <iostream>
using namespace std;

class Node
{
public:
  int data;
  Node *next;

  Node(int d)
  {
    data = d;
    next = NULL;
  }
};

class LinkedList
{
public:
  Node *head;

  LinkedList()
  {
    head = NULL;
  }
  void insertAtBeginning(int val)
  {
    Node *temp = new Node(val);
    temp->next = head;
    head = temp;
  }

  Node *insertAtEnd(Node *node, int val)
  {
    if (node == NULL)
      return new Node(val);

    node->next = insertAtEnd(node->next, val);
    return node;
  }

  Node *insertAtPosition(Node *node, int val, int pos)
  {
    if (pos == 1)
    {
      Node *temp = new Node(val);
      temp->next = node;
      return temp;
    }

    if (node == NULL)
      return NULL;

    node->next = insertAtPosition(node->next, val, pos - 1);

    return node;
  }

  Node *deleteByValue(Node *node, int val)
  {
    if (node == NULL)
      return NULL;

    if (node->data == val)
    {
      Node *temp = node->next;
      delete node;
      return temp;
    }

    node->next = deleteByValue(node->next, val);

    return node;
  }

  Node *deleteAtPosition(Node *node, int pos)
  {
    if (node == NULL)
      return NULL;

    if (pos == 1)
    {
      Node *temp = node->next;
      delete node;
      return temp;
    }

    node->next = deleteAtPosition(node->next, pos - 1);

    return node;
  }

  int search(Node *node, int val, int pos = 1)
  {
    if (node == NULL)
      return -1;

    if (node->data == val)
      return pos;

    return search(node->next, val, pos + 1);
  }

  void print(Node *node)
  {
    if (node == NULL)
      return;

    cout << node->data << " ";
    print(node->next);
  }
};

int main()
{
  LinkedList list;

  list.head = list.insertAtEnd(list.head, 10);
  list.head = list.insertAtEnd(list.head, 20);
  list.head = list.insertAtEnd(list.head, 30);

  cout << "List: ";
  list.print(list.head);

  cout << "\n";

  list.head = list.insertAtPosition(list.head, 25, 3);

  cout << "After insertion: ";
  list.print(list.head);

  cout << "\n";

  list.head = list.deleteByValue(list.head, 20);

  cout << "After deletion: ";
  list.print(list.head);

  cout << "\n";

  cout << "Position of 30: "
       << list.search(list.head, 30);

  return 0;
}